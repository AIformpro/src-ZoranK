# ZGS 1.1

TTL + hash chaining.
