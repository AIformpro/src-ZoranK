# Validation

INDUS vs META validators.
