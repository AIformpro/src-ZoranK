def validate(answer, policy_rules=None): return True
