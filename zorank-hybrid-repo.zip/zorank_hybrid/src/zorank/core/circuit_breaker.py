class CircuitBreaker:
    pass
